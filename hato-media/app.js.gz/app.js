const ARTICLES = [{"id":1,"category":"UKRAINE","title":"政府、復旧予算の追加配分案を発表　住宅再建を優先へ","summary":"被災住宅と自治体インフラへの追加支援を盛り込む案。対象地域と財源が焦点。","source":"HATO DEMO","time":"06:07","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「政府、復旧予算の追加配分案を発表　住宅再建を優先へ」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":2,"category":"UKRAINE","title":"議会委員会、徴税制度の改正案を修正　中小企業への影響を緩和","summary":"当初案から負担条件が変更。採決前にどこが変わったのかを見る。","source":"HATO DEMO","time":"07:14","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「議会委員会、徴税制度の改正案を修正　中小企業への影響を緩和」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":3,"category":"UKRAINE","title":"大統領府、停戦協議をめぐる表現を変更　前日より条件を具体化","summary":"発言のトーンではなく、交渉条件として新しく示された点を比較。","source":"HATO DEMO","time":"08:21","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「大統領府、停戦協議をめぐる表現を変更　前日より条件を具体化」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":4,"category":"UKRAINE","title":"汚職捜査機関の人事案が国会へ　独立性をめぐり与野党が対立","summary":"制度改革と人事が絡む案件。採決日程と修正案が次の焦点。","source":"HATO DEMO","time":"09:28","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「汚職捜査機関の人事案が国会へ　独立性をめぐり与野党が対立」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":5,"category":"UKRAINE","title":"政府、国外避難者の帰還支援策を拡充へ　住宅・就労を一体支援","summary":"帰国後の住居と仕事を同時に支える制度案。対象条件を整理。","source":"HATO DEMO","time":"10:35","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「政府、国外避難者の帰還支援策を拡充へ　住宅・就労を一体支援」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":6,"category":"UKRAINE","title":"エネルギー省、冬季向け備蓄計画を更新　発電設備の修復を前倒し","summary":"冬に向けた電力・燃料確保の計画が更新。生活への影響を確認。","source":"HATO DEMO","time":"11:42","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「エネルギー省、冬季向け備蓄計画を更新　発電設備の修復を前倒し」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":7,"category":"LIFE","title":"家庭向け電気料金、来月も据え置きへ　政府が方針を発表","summary":"家計への影響が大きい料金政策。適用期間と例外条件を確認。","source":"HATO DEMO","time":"05:49","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「家庭向け電気料金、来月も据え置きへ　政府が方針を発表」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":8,"category":"LIFE","title":"主要都市で食品価格にばらつき　卵と乳製品は上昇、穀物は横ばい","summary":"全国平均だけでなく都市別の価格差を見る。","source":"HATO DEMO","time":"06:56","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「主要都市で食品価格にばらつき　卵と乳製品は上昇、穀物は横ばい」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":9,"category":"LIFE","title":"新学期の対面授業基準を教育省が更新　避難設備の条件を厳格化","summary":"学校ごとに対面・オンライン判断が分かれる可能性。","source":"HATO DEMO","time":"07:03","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「新学期の対面授業基準を教育省が更新　避難設備の条件を厳格化」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":10,"category":"LIFE","title":"地方病院への医師派遣制度を拡大　不足地域に追加枠","summary":"医療アクセスの地域差を埋める施策。対象地域と人数が焦点。","source":"HATO DEMO","time":"08:10","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「地方病院への医師派遣制度を拡大　不足地域に追加枠」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":11,"category":"LIFE","title":"キーウの賃貸住宅、夏以降も高止まり　避難者流入で小型物件が不足","summary":"住宅価格と人口移動の関係を確認。","source":"HATO DEMO","time":"09:17","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「キーウの賃貸住宅、夏以降も高止まり　避難者流入で小型物件が不足」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":12,"category":"LIFE","title":"建設・物流の求人が増加　復旧需要で人手不足が続く","summary":"賃金が上がっている職種と地域を分けて見る。","source":"HATO DEMO","time":"10:24","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「建設・物流の求人が増加　復旧需要で人手不足が続く」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":13,"category":"LIFE","title":"年金の追加給付対象を拡大　申請不要の世帯も","summary":"誰が対象で、いつ反映されるのかを簡潔に整理。","source":"HATO DEMO","time":"11:31","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「年金の追加給付対象を拡大　申請不要の世帯も」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":14,"category":"REGIONS","title":"ハルキウ、市内交通を一部再開　夜間被害から復旧進む","summary":"攻撃そのものではなく、翌日の生活インフラがどこまで戻ったかを見る。","source":"HATO DEMO","time":"05:38","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「ハルキウ、市内交通を一部再開　夜間被害から復旧進む」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":15,"category":"REGIONS","title":"オデーサ港、貨物処理を再開　輸出遅延の解消に向け臨時体制","summary":"港湾停止の経済影響と復旧の進み具合を確認。","source":"HATO DEMO","time":"06:45","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「オデーサ港、貨物処理を再開　輸出遅延の解消に向け臨時体制」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":16,"category":"REGIONS","title":"キーウ市、地下シェルターの改修計画を前倒し","summary":"予算と対象施設が具体化。市民生活に直結する自治体ニュース。","source":"HATO DEMO","time":"07:52","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「キーウ市、地下シェルターの改修計画を前倒し」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":17,"category":"REGIONS","title":"スーミ州、国境地域の学校でオンライン授業を延長","summary":"安全判断が教育現場に与える影響を追う。","source":"HATO DEMO","time":"08:59","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「スーミ州、国境地域の学校でオンライン授業を延長」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":18,"category":"REGIONS","title":"ムィコラーイウ、水道復旧区域を拡大　残る課題は水質管理","summary":"復旧率だけでなく、日常利用できる状態かを確認。","source":"HATO DEMO","time":"09:06","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「ムィコラーイウ、水道復旧区域を拡大　残る課題は水質管理」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":19,"category":"WAR","title":"東部戦線で攻撃方向に変化　複数地点の動きを地図で確認","summary":"占領面積だけでなく、攻撃軸の変化が何を意味するかを見る。","source":"HATO DEMO","time":"10:13","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「東部戦線で攻撃方向に変化　複数地点の動きを地図で確認」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":20,"category":"WAR","title":"夜間攻撃で複数州に被害　防空発表と現地被害を分けて整理","summary":"迎撃数だけでは見えない被害とインフラ影響を確認。","source":"HATO DEMO","time":"11:20","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「夜間攻撃で複数州に被害　防空発表と現地被害を分けて整理」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":21,"category":"WAR","title":"長距離ドローン攻撃が増加　使用機種と到達距離に変化","summary":"新型か、運用方法の変更かを切り分けて見る。","source":"HATO DEMO","time":"05:27","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「長距離ドローン攻撃が増加　使用機種と到達距離に変化」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":22,"category":"WAR","title":"前線部隊への補給路で混雑　鉄道と道路の代替運用が進む","summary":"戦況より表に出にくい兵站の変化を追う。","source":"HATO DEMO","time":"06:34","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「前線部隊への補給路で混雑　鉄道と道路の代替運用が進む」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":23,"category":"WAR","title":"動員手続きの電子化を拡大　対象者への通知方法が変更","summary":"法律と実際の運用の差を確認。","source":"HATO DEMO","time":"07:41","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「動員手続きの電子化を拡大　対象者への通知方法が変更」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":24,"category":"WAR","title":"兵器損失をめぐり双方の数字に大差　映像確認できる範囲を整理","summary":"発表値と公開映像ベースの確認値を分けて表示。","source":"HATO DEMO","time":"08:48","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「兵器損失をめぐり双方の数字に大差　映像確認できる範囲を整理」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":25,"category":"WAR","title":"前線で地上無人機の補給利用が拡大　負傷者搬送にも試験導入","summary":"派手な実験ではなく、反復運用できているかを見る。","source":"HATO DEMO","time":"09:55","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「前線で地上無人機の補給利用が拡大　負傷者搬送にも試験導入」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":26,"category":"WAR","title":"複数旅団で通信方式を更新　電子戦対策を強化","summary":"通信障害への対処が現場運用をどう変えるか確認。","source":"HATO DEMO","time":"10:02","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「複数旅団で通信方式を更新　電子戦対策を強化」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":27,"category":"WORLD","title":"ロシア中銀、インフレ見通しを上方修正　軍需と人手不足が圧力","summary":"戦争継続能力を見るうえで国内経済の変化を追う。","source":"HATO DEMO","time":"11:09","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「ロシア中銀、インフレ見通しを上方修正　軍需と人手不足が圧力」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":28,"category":"WORLD","title":"米政府、追加支援の条件を説明　議会との調整が焦点","summary":"発表された支援額より、実行条件と時期を見る。","source":"HATO DEMO","time":"05:16","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「米政府、追加支援の条件を説明　議会との調整が焦点」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":29,"category":"WORLD","title":"EU、対ロ制裁の追加案を協議　海運と金融が中心","summary":"加盟国間の温度差と、実際に成立しそうな範囲を確認。","source":"HATO DEMO","time":"06:23","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「EU、対ロ制裁の追加案を協議　海運と金融が中心」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":30,"category":"WORLD","title":"NATO各国、防空装備の共同調達枠を拡大","summary":"発言ではなく契約・生産能力まで追う。","source":"HATO DEMO","time":"07:30","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「NATO各国、防空装備の共同調達枠を拡大」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":31,"category":"WORLD","title":"ポーランド、東部国境の防衛投資を追加　インフラ整備も対象","summary":"軍備だけでなく道路・通信など後方基盤への投資を確認。","source":"HATO DEMO","time":"08:37","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「ポーランド、東部国境の防衛投資を追加　インフラ整備も対象」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":32,"category":"WORLD","title":"ドイツ、ウクライナ向け装備の納入日程を前倒し","summary":"約束ではなく、いつ届くのかを時系列で確認。","source":"HATO DEMO","time":"09:44","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「ドイツ、ウクライナ向け装備の納入日程を前倒し」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":33,"category":"WORLD","title":"フランスと英国、長距離兵器をめぐり共同協議","summary":"両国の発言の違いと実務協議の進展を整理。","source":"HATO DEMO","time":"10:51","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「フランスと英国、長距離兵器をめぐり共同協議」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":34,"category":"WORLD","title":"中国、対ロ貿易で一部品目の輸出管理を強化","summary":"公式説明と実際の貿易データが一致するかを見る。","source":"HATO DEMO","time":"11:58","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「中国、対ロ貿易で一部品目の輸出管理を強化」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":35,"category":"WORLD","title":"北朝鮮とロシアの軍事協力をめぐり新たな衛星画像","summary":"確認できる事実と推測を切り分ける。","source":"HATO DEMO","time":"05:05","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「北朝鮮とロシアの軍事協力をめぐり新たな衛星画像」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"重要な発言がある場合だけ、発言者・時刻・立場とともに表示します。発言が重要でない記事では、この項目自体を出しません。","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":36,"category":"TECH","title":"新型電子戦装置、FPVドローン対策で前線投入　通信耐性が焦点","summary":"スペックではなく実戦でどの程度機能しているかを見る。","source":"HATO DEMO","time":"06:12","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「新型電子戦装置、FPVドローン対策で前線投入　通信耐性が焦点」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":37,"category":"TECH","title":"低コスト迎撃ドローンの量産計画が拡大　1機あたり費用を比較","summary":"高価なミサイルとのコスト交換比が重要。","source":"HATO DEMO","time":"07:19","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「低コスト迎撃ドローンの量産計画が拡大　1機あたり費用を比較」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":38,"category":"TECH","title":"AIによる標的認識支援を試験運用　完全自律ではなく補助用途","summary":"「AI兵器」という言葉だけでなく実際の役割を確認。","source":"HATO DEMO","time":"08:26","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「AIによる標的認識支援を試験運用　完全自律ではなく補助用途」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":39,"category":"TECH","title":"商用衛星会社、撮像頻度を増加　前線監視の空白を短縮","summary":"画像解像度より、更新頻度が作戦に与える意味を見る。","source":"HATO DEMO","time":"09:33","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「商用衛星会社、撮像頻度を増加　前線監視の空白を短縮」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":40,"category":"TECH","title":"地上ロボットの補給任務が定常化　運用回数を公開","summary":"試作段階から日常運用へ移ったかがポイント。","source":"HATO DEMO","time":"10:40","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「地上ロボットの補給任務が定常化　運用回数を公開」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":41,"category":"TECH","title":"対ドローン用レーザー試験、悪天候時の課題が明らかに","summary":"成功映像だけでなく制約条件を確認。","source":"HATO DEMO","time":"11:47","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「対ドローン用レーザー試験、悪天候時の課題が明らかに」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":42,"category":"OSINT","title":"Telegramで「大規模突破」の投稿拡散　公開映像では範囲を確認できず","summary":"速報性の高い主張を、確認済み・未確認に分ける。","source":"HATO DEMO","time":"05:54","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「Telegramで「大規模突破」の投稿拡散　公開映像では範囲を確認できず」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":43,"category":"OSINT","title":"駅周辺の映像を位置特定　撮影時刻はまだ未確認","summary":"場所が分かっても時刻が分からなければ断定しない。","source":"HATO DEMO","time":"06:01","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「駅周辺の映像を位置特定　撮影時刻はまだ未確認」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":44,"category":"OSINT","title":"衛星画像で施設の損傷を確認　原因は特定できず","summary":"見えるものと推測を分離する。","source":"HATO DEMO","time":"07:08","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「衛星画像で施設の損傷を確認　原因は特定できず」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":45,"category":"OSINT","title":"同じ攻撃を国内紙と海外紙が別の角度で報道","summary":"見出しと引用対象の違いから、報道フレームを比較。","source":"HATO DEMO","time":"08:15","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「同じ攻撃を国内紙と海外紙が別の角度で報道」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":46,"category":"OSINT","title":"SNSで拡散した「新兵器」映像、過去映像の再投稿と判明","summary":"古い映像の再利用を時系列で検証。","source":"HATO DEMO","time":"09:22","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「SNSで拡散した「新兵器」映像、過去映像の再投稿と判明」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"},{"id":47,"category":"OSINT","title":"複数の公開情報から部隊移動を確認　目的は未確定","summary":"複数ソースで一致した事実だけを示す。","source":"HATO DEMO","time":"10:29","why":"この出来事が政策・生活・戦況・経済のどこに影響するのかを、ニュースそのものとは分けて説明します。","details":"これは表示確認用のデモ記事です。本番では当日の実際の一次資料・現地報道・国際報道から取得した情報に差し替わります。「複数の公開情報から部隊移動を確認　目的は未確定」について、数字・場所・時刻・発言者を分離し、確認できた事実だけを本文に残す設計です。","statements":"","reality":"確認度が重要な記事だけ表示します。単一投稿や未確認情報は、確認済み情報と混ぜません。","previous":"8/12　前提となる動き\n8/13　前日の更新\nTODAY　今日、新しく確認できた点","watch":"次に確認すべき公式発表、追加資料、現地確認などを短く示します。"}];
const FORCE_COMPLETE = false;
const STORAGE_KEY = 'hato-read-v1';
let readSet = new Set();
try { readSet = new Set(JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]')); } catch(e) {}
if (FORCE_COMPLETE) readSet = new Set(ARTICLES.map(a=>a.id));
let currentCategory = 'TOP';
const TOP_IDS = [3,20,28,27,7,29,14,36,42];
const CONTENT_CATEGORIES = ['UKRAINE','LIFE','REGIONS','WAR','WORLD','TECH','OSINT'];
let query = '';
let listScroll = 0;
let articleId = null;
let speechState = {active:false,paused:false,mode:null,text:'',duration:0,position:0,charIndex:0,startedAt:0,utterance:null,raf:0};
let audioCtx = null;
let meterPlayed = false;

const $ = s => document.querySelector(s);
const $$ = s => [...document.querySelectorAll(s)];
function saveRead(){ if(!FORCE_COMPLETE){ try{ localStorage.setItem(STORAGE_KEY, JSON.stringify([...readSet])); }catch(e){} } }
function esc(s){return String(s).replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','\"':'&quot;'}[c]));}

function artSVG(a, displayNo=a.id){
  const c=a.category, label=esc(c), orange='#ff5a00', white='#f5f5f2', gray='#8c8c8c', dark='#111111';
  let scene='';
  if(c==='LIFE') scene=`<rect x="90" y="120" width="190" height="210" fill="#303030"/><rect x="305" y="75" width="235" height="255" fill="#202020"/><g fill="${white}">${[0,1,2].map(r=>[0,1,2,3].map(k=>`<rect x="${330+k*43}" y="${105+r*57}" width="20" height="30" opacity="${.28+(r+k)%3*.18}"/>`).join('')).join('')}</g><path d="M60 360 H730" stroke="${white}" opacity=".4"/><path d="M180 390 C330 330 490 330 690 390" fill="none" stroke="${orange}" stroke-width="13"/>`;
  else if(c==='REGIONS') scene=`<path d="M70 330 L140 270 205 318 280 175 350 315 430 230 500 318 585 145 665 325 740 270 V420 H70Z" fill="#2a2a2a"/><g stroke="${white}" opacity=".42">${[130,230,330,430,530,630].map(x=>`<path d="M${x} 95 V390"/>`).join('')}</g><circle cx="585" cy="145" r="18" fill="${orange}"/>`;
  else if(c==='WAR') scene=`<circle cx="410" cy="225" r="150" fill="none" stroke="#3a3a3a" stroke-width="2"/><circle cx="410" cy="225" r="95" fill="none" stroke="#555" stroke-width="2"/><path d="M410 225 L690 105" stroke="${orange}" stroke-width="9"/><path d="M120 330 L265 245 350 300 490 190 650 245" fill="none" stroke="${white}" stroke-width="3" opacity=".55"/><circle cx="690" cy="105" r="13" fill="${orange}"/>`;
  else if(c==='TECH') scene=`<g fill="none" stroke="${white}" opacity=".5" stroke-width="3"><path d="M90 105 H270 V180 H410 V95 H690"/><path d="M105 330 H245 V250 H520 V330 H700"/><path d="M180 75 V370"/><path d="M585 75 V370"/></g><g fill="${orange}"><circle cx="270" cy="180" r="14"/><circle cx="410" cy="95" r="14"/><circle cx="520" cy="250" r="14"/></g><rect x="315" y="155" width="155" height="145" fill="#262626" stroke="#777"/>`;
  else if(c==='OSINT') scene=`<g fill="none" stroke="${white}" opacity=".6"><circle cx="405" cy="225" r="138"/><circle cx="405" cy="225" r="72"/><path d="M405 48 V402 M228 225 H582"/></g><rect x="86" y="78" width="112" height="80" fill="#2b2b2b"/><rect x="612" y="294" width="105" height="74" fill="#333"/><circle cx="405" cy="225" r="17" fill="${orange}"/><path d="M405 225 L655 331" stroke="${orange}" stroke-width="7"/>`;
  else scene=`<circle cx="405" cy="225" r="155" fill="#252525"/><path d="M278 177 C335 106 438 102 510 161 C545 190 559 252 522 303 C475 366 354 366 292 292 C255 248 250 215 278 177Z" fill="#444"/><path d="M190 340 C300 260 410 305 610 150" fill="none" stroke="${orange}" stroke-width="12"/><circle cx="610" cy="150" r="16" fill="${orange}"/>`;
  return `<svg viewBox="0 0 800 450" role="img" aria-label="${label} の記事ビジュアル"><rect width="800" height="450" fill="${dark}"/>${scene}<rect x="46" y="36" width="8" height="48" fill="${orange}"/><text x="72" y="66" fill="${white}" font-family="Arial, sans-serif" font-size="23" font-weight="700" letter-spacing="3">HATO / ${label}</text><text x="720" y="408" fill="${gray}" font-family="Arial, sans-serif" font-size="18" text-anchor="end">${String(displayNo).padStart(2,'0')}</text></svg>`;
}

function categoryItems(cat){
  if(cat==='TOP') return TOP_IDS.map(id=>ARTICLES.find(a=>a.id===id)).filter(Boolean);
  return ARTICLES.filter(a=>a.category===cat);
}
function chapterItems(cat){
  if(cat==='TOP') return categoryItems('TOP');
  return categoryItems(cat).filter(a=>!TOP_IDS.includes(a.id));
}
function categoryReadCount(cat){ return chapterItems(cat).filter(a=>readSet.has(a.id)).length; }
function updateCategoryStatus(){
  $$('.cat-btn').forEach(btn=>{
    const cat=btn.dataset.cat, total=chapterItems(cat).length, read=categoryReadCount(cat);
    let status=btn.querySelector('.cat-status');
    if(!status){ status=document.createElement('span'); status.className='cat-status'; btn.appendChild(status); }
    status.textContent=read>=total && total ? '✓ 完了' : `${read}/${total}`;
    btn.classList.toggle('active',cat===currentCategory);
  });
  const total=chapterItems(currentCategory).length, read=categoryReadCount(currentCategory);
  const current=$('#categoryCurrent'), currentStatus=$('#categoryCurrentStatus');
  if(current) current.textContent=currentCategory;
  if(currentStatus) currentStatus.textContent=read>=total && total ? '✓' : `${read}/${total}`;
}
function renderCategoryOverview(){
  const box=$('#categoryOverview');
  if(box){ box.classList.remove('show'); box.innerHTML=''; }
}
function updateProgress(){
  const n=readSet.size;
  $('#dayCount').textContent=`${n} / ${ARTICLES.length}`;
  $('#dayFill').style.width=`${n/ARTICLES.length*100}%`;
  updateCategoryStatus();
  const lock=$('#endLock'), comp=$('#completion');
  if(n>=ARTICLES.length){ lock.style.display='none'; comp.classList.add('unlocked'); }
  else { comp.classList.remove('unlocked'); }
  renderCategoryOverview();
}
function filtered(){
  if(!query) return ARTICLES;
  const q=query.toLowerCase();
  return ARTICLES.filter(a=>(a.title+' '+a.summary+' '+a.category).toLowerCase().includes(q));
}
function storyHTML(a, lead=false, displayNo=a.id){
  const read=readSet.has(a.id);
  if(lead){return `<article class="lead ${read?'read':''}" data-id="${a.id}">
    <div class="kicker">TOP · ${a.category}</div>
    <h1><button class="open-article" data-id="${a.id}">${esc(a.title)}</button></h1>
    <p class="summary">${esc(a.summary)}</p>
    <button class="open-article lead-art" data-id="${a.id}" aria-label="記事を開く">${artSVG(a,displayNo)}</button>
    <div class="meta"><a class="source-link" href="#" onclick="return false">${a.source}</a><span>${a.time}</span>${read?'<span>✓ READ</span>':''}</div>
  </article>`}
  return `<article class="story ${read?'read':''}" data-id="${a.id}">
    <div class="story-num">${String(displayNo).padStart(2,'0')}</div>
    <div class="story-main">
      <div class="story-topline"><span class="story-cat">${a.category}</span><span class="read-check">✓ READ</span></div>
      <h2><button class="open-article" data-id="${a.id}">${esc(a.title)}</button></h2>
      <p>${esc(a.summary)}</p>
      <div class="meta"><a class="source-link" href="#" onclick="return false">${a.source}</a><span>${a.time}</span></div>
    </div>
    <button class="open-article story-art" data-id="${a.id}" aria-label="記事を開く">${artSVG(a,displayNo)}</button>
  </article>`;
}
function updateEndVisibility(){
  const lock=$('#endLock'), comp=$('#completion'), n=readSet.size;
  if(query){ lock.style.display='none'; comp.style.display='none'; return; }
  comp.style.display='';
  if(n>=ARTICLES.length){
    lock.style.display='none';
    comp.classList.add('unlocked');
  }else{
    comp.classList.remove('unlocked');
    lock.style.display='block';
    lock.className='timeline-end-note';
    lock.innerHTML=`今日のブリーフはあと <strong>${ARTICLES.length-n}</strong> 本。ここで今日のニュースは終わりです。`;
  }
}
function chapterHeaderHTML(cat){
  const items=chapterItems(cat), read=categoryReadCount(cat), done=items.length>0 && read>=items.length;
  return `<div class="chapter-head ${done?'chapter-done':''}"><div class="chapter-name">${cat}</div><div class="chapter-status"><span class="chapter-count">${done?'✓ 完了':`${read} / ${items.length}`}</span><span class="chapter-note">${done?'この章は読了':'この章の進捗'}</span></div></div>`;
}
function renderFeed(){
  updateCategoryStatus();
  const feed=$('#feed');
  if(query){
    const items=filtered();
    feed.innerHTML=items.length ? items.map((a,i)=>storyHTML(a,false,i+1)).join('') : '<div class="empty-state">該当する記事はありません。</div>';
    $$('.open-article').forEach(b=>b.addEventListener('click',()=>openArticle(Number(b.dataset.id))));
    updateEndVisibility();
    return;
  }

  const topItems=chapterItems('TOP');
  let html=`<section id="chapter-TOP" class="timeline-chapter timeline-top">`;
  if(topItems.length){
    html+=storyHTML(topItems[0],true,1);
    html+=topItems.slice(1).map((a,i)=>storyHTML(a,false,i+2)).join('');
  }
  html+='</section>';

  CONTENT_CATEGORIES.forEach(cat=>{
    const items=chapterItems(cat);
    html+=`<section id="chapter-${cat}" class="timeline-chapter">${chapterHeaderHTML(cat)}${items.map((a,i)=>storyHTML(a,false,i+1)).join('')}</section>`;
  });

  feed.innerHTML=html;
  $$('.open-article').forEach(b=>b.addEventListener('click',()=>openArticle(Number(b.dataset.id))));
  updateEndVisibility();
}
function closeCategorySelector(){
  const selector=$('#categorySelector'), toggle=$('#categoryToggle');
  if(selector) selector.classList.remove('open');
  if(toggle) toggle.setAttribute('aria-expanded','false');
}
function toggleCategorySelector(){
  const selector=$('#categorySelector'), toggle=$('#categoryToggle');
  if(!selector||!toggle)return;
  const open=!selector.classList.contains('open');
  selector.classList.toggle('open',open);
  toggle.setAttribute('aria-expanded',open?'true':'false');
}
function setCategory(cat){
  currentCategory=cat;
  closeCategorySelector();
  if(query){ query=''; const input=$('#searchInput'); if(input) input.value=''; renderFeed(); }
  updateCategoryStatus();
  const target=$(`#chapter-${cat}`);
  if(target) target.scrollIntoView({behavior:'smooth',block:'start'});
}

function syncCurrentChapter(){
  if(query)return;
  let active='TOP';
  ['TOP',...CONTENT_CATEGORIES].forEach(cat=>{
    const el=$(`#chapter-${cat}`);
    if(el && el.getBoundingClientRect().top<=116) active=cat;
  });
  if(active!==currentCategory){ currentCategory=active; updateCategoryStatus(); }
}

function openArticle(id){
  const a=ARTICLES.find(x=>x.id===id); if(!a)return;
  listScroll=window.scrollY; articleId=id; readSet.add(id); saveRead(); updateProgress(); renderFeed();
  const showReality=['WAR','OSINT','REGIONS'].includes(a.category);
  $('#articleContent').innerHTML=`
    <div class="article-cat">${a.category}</div>
    <h1 class="article-title">${esc(a.title)}</h1>
    <p class="article-dek">${esc(a.summary)}</p>
    <div class="article-meta"><a href="#" onclick="return false" class="source-link">${a.source}</a> &nbsp; ${a.time}</div>
    <div class="article-hero-art">${artSVG(a)}</div>

    <section class="article-glance">
      <h3>3行でわかる</h3>
      <p>${esc(a.summary)}</p>
      <p>${esc(a.why)}</p>
      <p>${esc(a.watch)}</p>
    </section>

    <section class="article-section"><h3>何が起きた？</h3><p>${esc(a.details)}</p></section>
    <section class="article-section"><h3>なぜ重要？</h3><p>${esc(a.why)}</p></section>
    ${a.statements?`<section class="article-section"><h3>誰が何を言った？</h3><p>${esc(a.statements)}</p></section>`:''}
    ${showReality&&a.reality?`<section class="article-section"><h3>どこまで確認できてる？</h3><p>${esc(a.reality)}</p></section>`:''}
    ${a.previous?`<section class="article-section"><h3>これまでの流れ</h3><p class="timeline">${esc(a.previous)}</p></section>`:''}
    ${a.previous?`<section class="article-section"><h3>今日変わったこと</h3><p>前日までと比べて、今日更新された点だけをここに短くまとめます。</p></section>`:''}
    <section class="article-section"><h3>次に見るポイント</h3><p>${esc(a.watch)}</p></section>
    <section class="article-sources-wrap"><h3>情報源</h3><div class="article-sources"><a class="source-link" href="#" onclick="return false">${a.source}</a><a class="source-link" href="#" onclick="return false">一次資料</a><a class="source-link" href="#" onclick="return false">現地発表</a></div></section>`;
  const view=$('#articleView'); view.classList.add('open'); document.body.classList.add('lock','article-open'); view.scrollTop=0; $('#articleProgress').style.width='0';
}
function closeArticle(){
  const view=$('#articleView'); view.classList.remove('open'); document.body.classList.remove('lock','article-open'); setTimeout(()=>window.scrollTo(0,listScroll),0); articleId=null;
}
function articleScroll(){
  const v=$('#articleView'); const max=v.scrollHeight-v.clientHeight; const pct=max>0?v.scrollTop/max*100:0; $('#articleProgress').style.width=pct+'%';
}

function openMenu(){ $('#menu').classList.add('open'); document.body.classList.add('lock'); }
function closeMenu(){ $('#menu').classList.remove('open'); document.body.classList.remove('lock'); }
function showPage(name){
  closeMenu();
  $$('.menu-link').forEach(b=>b.classList.toggle('active',b.dataset.page===name));
  $('#todayView').style.display=name==='today'?'block':'none';
  $$('.page-section').forEach(s=>s.classList.toggle('active',s.id===name+'Page'));
  if(name==='audio'){ openAudio(); $('#todayView').style.display='block'; $$('.page-section').forEach(s=>s.classList.remove('active')); }
  window.scrollTo(0,0);
}

let audioContextDate='TODAY';
function openAudio(dateLabel='TODAY'){
  audioContextDate=dateLabel || 'TODAY';
  $('#sheetTitle').textContent=audioContextDate==='TODAY' ? 'AUDIO' : `AUDIO · ${audioContextDate}`;
  $('#scrim').classList.add('open'); $('#audioSheet').classList.add('open'); document.body.classList.add('lock');
}
function closeAudio(){ $('#scrim').classList.remove('open'); $('#audioSheet').classList.remove('open'); document.body.classList.remove('lock'); }
function buildSpeechText(mode){
  const items= mode==='digest' ? ARTICLES.slice(0,8) : ARTICLES;
  const preface=audioContextDate==='TODAY'?'':`${audioContextDate}の音声アーカイブ。プロトタイプではデモ記事を読み上げます。`;
  return preface+items.map((a,i)=>`${i+1}。${a.title}。${a.summary}`).join('。');
}
function estimateSpeechDuration(text){
  // デモ用の概算。本番MP3では audio.duration をそのまま使う。
  return Math.max(20,text.length/5.2);
}
function fmtTime(sec){
  sec=Math.max(0,Math.round(sec||0));
  const m=Math.floor(sec/60),s=String(sec%60).padStart(2,'0');
  return `${m}:${s}`;
}
function getSpeechPosition(){
  if(!speechState.active)return speechState.position||0;
  if(speechState.paused)return speechState.position||0;
  return Math.min(speechState.duration,(performance.now()-speechState.startedAt)/1000);
}
function updateSpeechUI(){
  if(!speechState.active)return;
  const pos=getSpeechPosition(),dur=Math.max(1,speechState.duration);
  speechState.position=pos;
  const seek=$('#miniSeek');
  seek.value=Math.round(pos/dur*1000);
  seek.style.setProperty('--seekPct',`${Math.min(100,pos/dur*100)}%`);
  $('#miniCurrent').textContent=fmtTime(pos);
  $('#miniDuration').textContent=fmtTime(dur);
  speechState.raf=requestAnimationFrame(updateSpeechUI);
}
function speakFromPosition(position,keepPaused=false){
  if(!('speechSynthesis' in window)||!speechState.text)return;
  speechSynthesis.cancel();
  const dur=Math.max(1,speechState.duration);
  const pos=Math.max(0,Math.min(dur-.05,position||0));
  const startChar=Math.min(speechState.text.length-1,Math.floor((pos/dur)*speechState.text.length));
  const u=new SpeechSynthesisUtterance(speechState.text.slice(startChar));
  u.lang='ja-JP';u.rate=.98;u.pitch=1;
  speechState.position=pos;
  speechState.charIndex=startChar;
  speechState.startedAt=performance.now()-pos*1000;
  speechState.utterance=u;
  u.onboundary=e=>{
    if(typeof e.charIndex==='number'){
      speechState.charIndex=startChar+e.charIndex;
      speechState.position=(speechState.charIndex/Math.max(1,speechState.text.length))*speechState.duration;
      speechState.startedAt=performance.now()-speechState.position*1000;
    }
  };
  u.onend=()=>{ if(speechState.active && !speechState.paused && getSpeechPosition()>=speechState.duration*.97) stopSpeech(false); };
  speechSynthesis.speak(u);
  if(keepPaused){setTimeout(()=>{speechSynthesis.pause();},30);}
}
function startSpeech(mode){
  closeAudio();
  if(!('speechSynthesis' in window)){alert('このブラウザではデモ音声を再生できません。本番版ではMP3音声を使用します。');return;}
  const text=buildSpeechText(mode);
  if(speechState.raf)cancelAnimationFrame(speechState.raf);
  speechState={active:true,paused:false,mode,text,duration:estimateSpeechDuration(text),position:0,charIndex:0,startedAt:performance.now(),utterance:null,raf:0};
  speakFromPosition(0,false);
  $('#miniPlayer').classList.add('show');
  $('#miniTitle').textContent=(audioContextDate==='TODAY'?'':audioContextDate+' · ')+(mode==='digest'?'重要ニュースだけ':'すべての概要');
  $('#miniStatus').textContent='デモ音声を再生中';
  $('#miniPlay').textContent='Ⅱ';
  updateSpeechUI();
}
function toggleSpeech(){
  if(!speechState.active)return;
  if(speechState.paused){
    speechSynthesis.resume();speechState.paused=false;speechState.startedAt=performance.now()-speechState.position*1000;
    $('#miniPlay').textContent='Ⅱ';$('#miniStatus').textContent='再生中';updateSpeechUI();
  }else{
    speechState.position=getSpeechPosition();speechSynthesis.pause();speechState.paused=true;
    if(speechState.raf)cancelAnimationFrame(speechState.raf);
    $('#miniPlay').textContent='▶';$('#miniStatus').textContent='一時停止';
  }
}
function seekSpeech(seconds){
  if(!speechState.active)return;
  const target=Math.max(0,Math.min(speechState.duration-.05,getSpeechPosition()+seconds));
  const wasPaused=speechState.paused;
  speechState.position=target;
  speakFromPosition(target,wasPaused);
  if(!wasPaused){speechState.startedAt=performance.now()-target*1000;updateSpeechUI();}
  else{
    const seek=$('#miniSeek'),dur=Math.max(1,speechState.duration);
    seek.value=Math.round(target/dur*1000);seek.style.setProperty('--seekPct',`${target/dur*100}%`);
    $('#miniCurrent').textContent=fmtTime(target);
  }
}
function seekSpeechToFraction(fraction){
  if(!speechState.active)return;
  const target=Math.max(0,Math.min(speechState.duration-.05,speechState.duration*fraction));
  const wasPaused=speechState.paused;
  speechState.position=target;
  speakFromPosition(target,wasPaused);
  if(!wasPaused){speechState.startedAt=performance.now()-target*1000;updateSpeechUI();}
  $('#miniCurrent').textContent=fmtTime(target);
}
function stopSpeech(hide=true){
  if('speechSynthesis' in window)speechSynthesis.cancel();
  if(speechState.raf)cancelAnimationFrame(speechState.raf);
  speechState={active:false,paused:false,mode:null,text:'',duration:0,position:0,charIndex:0,startedAt:0,utterance:null,raf:0};
  if(hide)$('#miniPlayer').classList.remove('show');
  else{$('#miniStatus').textContent='再生終了';$('#miniPlay').textContent='▶';$('#miniSeek').value=1000;$('#miniSeek').style.setProperty('--seekPct','100%');}
}

function primeAudio(){
  if(audioCtx)return;
  try{ audioCtx=new (window.AudioContext||window.webkitAudioContext)(); }catch(e){}
}
function tickSequence(){
  if(!audioCtx || audioCtx.state!=='running')return;
  const now=audioCtx.currentTime;
  for(let i=0;i<18;i++){
    const o=audioCtx.createOscillator(), g=audioCtx.createGain(); o.type='sine'; o.frequency.value=860+i*22;
    g.gain.setValueAtTime(0.0001,now+i*.075); g.gain.exponentialRampToValueAtTime(.018,now+i*.075+.008); g.gain.exponentialRampToValueAtTime(.0001,now+i*.075+.035);
    o.connect(g);g.connect(audioCtx.destination);o.start(now+i*.075);o.stop(now+i*.075+.04);
  }
}

function completionScroll(){
  const comp=$('#completion'); if(!comp.classList.contains('unlocked')){document.body.classList.remove('completion-mode');return;}
  const vh=window.innerHeight;
  const cr=comp.getBoundingClientRect();
  document.body.classList.toggle('completion-mode', cr.top < vh*.35 && cr.bottom > vh*.15);
  const intro=$('#completionIntro').getBoundingClientRect();
  if(!meterPlayed && intro.top < vh*.62){ meterPlayed=true; $('#meterBars').classList.add('play'); $('#completionProgress').classList.add('play'); tickSequence(); }

  const smooth=(a,b,x)=>{const t=Math.max(0,Math.min(1,(x-a)/(b-a)));return t*t*(3-2*t)};

  // Future message: fixed in place. It only fades in and fades out — no slide, no scale.
  const fs=$('#futureScene'), fr=fs.getBoundingClientRect();
  const ftotal=Math.max(1,fr.height-vh); const fp=Math.max(0,Math.min(1,-fr.top/ftotal));
  const fadeIn=smooth(.05,.34,fp), fadeOut=1-smooth(.74,.995,fp), fo=Math.min(fadeIn,fadeOut);
  const future=$('#futureCopy');
  future.style.opacity=fo;
  future.style.filter='none';
  future.style.transform='none';

  // Scripture: fade the red field in normally. On exit, the field disappears and resolves into one red heart.
  const ss=$('#scriptureScene'), sr=ss.getBoundingClientRect();
  const stotal=Math.max(1,sr.height-vh), sp=Math.max(0,Math.min(1,-sr.top/stotal));
  const curtain=$('#redCurtain'), scripture=$('#scriptureCopy');

  if(sp<.24){
    const p=smooth(.01,.24,sp);
    curtain.style.setProperty('--fieldAlpha', `${p}`);
    curtain.style.setProperty('--heartOpacity','0');
    const so=smooth(.08,.24,sp);
    scripture.style.opacity=so;
    scripture.style.filter=`blur(${2.5*(1-so)}px)`;
  }else if(sp<.56){
    curtain.style.setProperty('--fieldAlpha','1');
    curtain.style.setProperty('--heartOpacity','1');
    scripture.style.opacity=1;
    scripture.style.filter='blur(0)';
  }else if(sp<.82){
    const p=smooth(.56,.82,sp);
    curtain.style.setProperty('--fieldAlpha', `${1-p}`);
    curtain.style.setProperty('--heartOpacity','1');
    const so=1-smooth(.56,.72,sp);
    scripture.style.opacity=so;
    scripture.style.filter=`blur(${2*(1-so)}px)`;
  }else if(sp<.94){
    curtain.style.setProperty('--fieldAlpha','0');
    curtain.style.setProperty('--heartOpacity','1');
    scripture.style.opacity=0;
    scripture.style.filter='blur(2px)';
  }else{
    const p=smooth(.94,.998,sp);
    curtain.style.setProperty('--fieldAlpha','0');
    curtain.style.setProperty('--heartOpacity', `${1-p}`);
    scripture.style.opacity=0;
    scripture.style.filter='blur(2px)';
  }

  // One ATTA only. The same visible bird approaches, kisses, then leaves.
  // The second image is used only as a hidden preload/source; it is never independently shown.
  const ks=$('#kissScene'), kr=ks.getBoundingClientRect();
  const ktotal=Math.max(1,kr.height-vh), kp=Math.max(0,Math.min(1,-kr.top/ktotal));
  const bird=$('#kissBird'), love=$('#loveLine'), normalPreload=$('#flyAway');
  if(!bird.dataset.kissSrc){ bird.dataset.kissSrc=bird.src; bird.dataset.normalSrc=normalPreload.src; }
  const kissSrc=bird.dataset.kissSrc, normalSrc=bird.dataset.normalSrc;
  normalPreload.style.display='none';

  if(kp<.005){
    if(bird.src!==normalSrc) bird.src=normalSrc;
    bird.style.opacity=0;
    bird.style.transform='translate3d(-22vw,8vh,-390px) scale(.36) rotate(-5deg)';
    love.style.opacity=0;
  }else if(kp<.68){
    if(bird.src!==normalSrc) bird.src=normalSrc;
    const p=smooth(.005,.68,kp);
    bird.style.opacity=Math.min(1,.10+p);
    bird.style.transform=`translate3d(${-22*(1-p)}vw,${8*(1-p)}vh,${-390*(1-p)}px) scale(${.36+.54*p}) rotate(${-5*(1-p)}deg)`;
    love.style.opacity=0;
  }else if(kp<.80){
    if(bird.src!==normalSrc) bird.src=normalSrc;
    const p=smooth(.68,.80,kp);
    bird.style.opacity=1;
    bird.style.transform=`translate3d(0,${-.8*p}vh,0) scale(${.90+.06*p}) rotate(0deg)`;
    love.style.opacity=0;
  }else if(kp<.90){
    if(bird.src!==kissSrc) bird.src=kissSrc;
    const p=smooth(.80,.90,kp);
    bird.style.opacity=1;
    bird.style.transform=`translate3d(0,-.8vh,0) scale(${.96+.10*p}) rotate(0deg)`;
    const lo=smooth(.84,.90,kp);
    love.style.opacity=lo;
    love.style.transform=`translateY(${8*(1-lo)}px)`;
  }else if(kp<.94){
    if(bird.src!==kissSrc) bird.src=kissSrc;
    bird.style.opacity=1;
    bird.style.transform='translate3d(0,-.8vh,0) scale(1.06)';
    love.style.opacity=1;
    love.style.transform='translateY(0)';
  }else if(kp<.998){
    if(bird.src!==normalSrc) bird.src=normalSrc;
    const p=smooth(.94,.998,kp);
    bird.style.opacity=1-smooth(.965,.998,kp);
    bird.style.transform=`translate3d(${48*p}vw,${-36*p}vh,0) scale(${1.0-.12*p}) rotate(${8*p}deg)`;
    love.style.opacity=1-smooth(.94,.975,kp);
  }else{
    if(bird.src!==normalSrc) bird.src=normalSrc;
    bird.style.opacity=0;
    love.style.opacity=0;
  }
}

function buildMeter(){
  const total=18;
  $('#meterBars').innerHTML=Array.from({length:total},(_,i)=>`<span class="meter-bar" style="--i:${i}"></span>`).join('');
}
function renderArchive(){
  const days=[['14 AUG','47 stories',readSet.size===47?'すべて読了 ✓':`${readSet.size} / 47`],['13 AUG','39 stories','21 / 39'],['12 AUG','44 stories',''],['11 AUG','42 stories','すべて読了 ✓'],['10 AUG','51 stories',''],['09 AUG','36 stories',''],['08 AUG','48 stories','']];
  $('#archiveRows').innerHTML=days.map((d,i)=>{
    const fullDate=`${d[0]} 2026`;
    return `<div class="archive-row" data-day="${i}" data-archive-date="${fullDate}">
      <button class="archive-main archive-day-open" data-day="${i}" data-date="${fullDate}"><span class="archive-date">${d[0]}</span><span class="archive-info">${d[1]}${d[2]?` · ${d[2]}`:''}</span><span class="archive-chev">›</span></button>
      <div class="archive-audio-line"><span class="archive-audio-label">AUDIO</span><button class="archive-audio-btn" data-archive-audio="digest" data-date="${fullDate}">12 min</button><button class="archive-audio-btn" data-archive-audio="all" data-date="${fullDate}">25 min</button></div>
    </div>`;
  }).join('');
  $$('#archiveRows .archive-day-open').forEach((b,i)=>b.addEventListener('click',()=>{ if(i===0)showPage('today'); else alert(`${days[i][0]} の保存済みHATOを開く導線です。プロトタイプでは現在日のデータのみ収録しています。`); }));
  $$('.archive-audio-btn').forEach(b=>b.addEventListener('click',e=>{e.stopPropagation();openAudio(b.dataset.date);}));
  const julyOpen=document.querySelector('[data-date="31 JUL 2026"].archive-day-open');
  if(julyOpen)julyOpen.addEventListener('click',()=>alert('31 JUL の保存済みHATOを開く導線です。プロトタイプでは現在日のデータのみ収録しています。'));
  const input=$('#archiveSearch');
  input.addEventListener('input',()=>{
    const q=input.value.trim().toLowerCase();
    const box=$('#archiveResults');
    if(!q){box.innerHTML='';return;}
    const hits=ARTICLES.filter(a=>(a.title+' '+a.summary).toLowerCase().includes(q)).slice(0,8);
    box.innerHTML=hits.length?hits.map(a=>`<button class="archive-result" data-id="${a.id}"><strong>${a.title}</strong><span>14 AUG 2026 · ${a.category}</span></button>`).join(''):'<div class="about-small">該当する記事はありません。</div>';
    $$('#archiveResults .archive-result').forEach(b=>b.addEventListener('click',()=>{showPage('today');setTimeout(()=>openArticle(Number(b.dataset.id)),50);}));
  });
}

function init(){
  buildMeter(); renderFeed(); updateProgress(); renderArchive();
  $$('.cat-btn').forEach(b=>b.addEventListener('click',()=>setCategory(b.dataset.cat)));
  $('#categoryToggle').addEventListener('click',toggleCategorySelector);
  document.addEventListener('click',e=>{const selector=$('#categorySelector'); if(selector && selector.classList.contains('open') && !selector.contains(e.target)) closeCategorySelector();});
  $$('.menu-open').forEach(b=>b.addEventListener('click',openMenu)); $('#menuClose').addEventListener('click',closeMenu);
  $('#searchBtn').addEventListener('click',()=>{const p=$('#searchPanel');p.classList.toggle('open'); if(p.classList.contains('open'))$('#searchInput').focus();});
  $('#searchInput').addEventListener('input',e=>{query=e.target.value;renderFeed();});
  $('#backArticle').addEventListener('click',closeArticle); $('#articleView').addEventListener('scroll',articleScroll,{passive:true});
  $('#playBtn').addEventListener('click',openAudio); $('#scrim').addEventListener('click',closeAudio); $('#audioClose').addEventListener('click',closeAudio);
  $$('.audio-option').forEach(b=>b.addEventListener('click',()=>startSpeech(b.dataset.mode)));
  $('#miniPlay').addEventListener('click',toggleSpeech); $('#miniClose').addEventListener('click',()=>stopSpeech(true));
  $('#miniBack10').addEventListener('click',()=>seekSpeech(-10));
  $('#miniForward10').addEventListener('click',()=>seekSpeech(10));
  $('#miniSeek').addEventListener('input',e=>{if(!speechState.active)return;const f=Number(e.target.value)/1000;const target=speechState.duration*f;$('#miniCurrent').textContent=fmtTime(target);e.target.style.setProperty('--seekPct',`${f*100}%`);});
  $('#miniSeek').addEventListener('change',e=>seekSpeechToFraction(Number(e.target.value)/1000));
  $$('.menu-link').forEach(b=>b.addEventListener('click',()=>showPage(b.dataset.page)));
  document.addEventListener('pointerdown',()=>{primeAudio(); if(audioCtx&&audioCtx.state==='suspended')audioCtx.resume();},{once:true});
  window.addEventListener('scroll',()=>requestAnimationFrame(()=>{completionScroll();syncCurrentChapter();}),{passive:true});
  if(FORCE_COMPLETE){ setTimeout(()=>{ const old=document.documentElement.style.scrollBehavior; document.documentElement.style.scrollBehavior='auto'; window.scrollTo(0,$('#completion').offsetTop); document.documentElement.style.scrollBehavior=old; completionScroll(); },160); }
}
document.addEventListener('DOMContentLoaded',init);